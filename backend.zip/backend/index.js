require("dotenv").config();

const express = require("express");
const cors = require("cors");
const path = require("path");
const db = require("./models");

const app = express();

// ✅ 1. CONFIGURACIÓN DE CORS (Para que el móvil pueda conectar)
const allowedOrigins = [
  "http://localhost:8100",   // Navegador PC
  "capacitor://localhost",   // App Android
  "http://localhost"         // App iOS
];

// ✅ ACTUALIZACIÓN DE CORS CON MÉTODO PATCH
const corsOptions = {
  origin: function (origin, callback) {
    if (!origin || allowedOrigins.indexOf(origin) !== -1) {
      callback(null, true);
    } else {
      callback(new Error("No permitido por CORS"));
    }
  },
  methods: ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"], // 👈 ¡He añadido PATCH aquí!
  credentials: true,
  allowedHeaders: ["Content-Type", "Authorization"] // Aseguramos que acepte estos headers
};

app.use(cors(corsOptions));
// ✅ 2. SERVIR IMÁGENES (Con máxima compatibilidad para Android/iOS)
app.use("/images", (req, res, next) => {
  res.set('Access-Control-Allow-Origin', '*');
  res.set('Cross-Origin-Resource-Policy', 'cross-origin'); // 👈 Esto evita bloqueos en móviles nuevos
  next();
}, express.static(path.join(__dirname, "public", "images")));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ✅ 3. SINCRONIZACIÓN DE BASE DE DATOS
db.sequelize.sync({ alter: true })
  .then(() => console.log("✅ Base de datos sincronizada"))
  .catch(err => console.error("❌ Error al sincronizar:", err));

// ✅ 4. RUTAS
app.get("/", (req, res) => res.json({ message: "Welcome to Waybee App" }));

require("./routes/auth.routes")(app);
require("./routes/usuario.routes")(app);
require("./routes/conductor.routes")(app);
require("./routes/vehiculo.routes")(app);
require("./routes/servicio.routes")(app); 
require("./routes/pago.routes")(app);
require("./routes/valoracion.routes")(app);
app.use('/favoritos', require('./routes/favorito.routes'));

// ✅ 5. MANEJADOR DE ERRORES
app.use((err, req, res, next) => {
  if (err && err.name === "MulterError") {
    if (err.code === "LIMIT_FILE_SIZE") {
      return res.status(400).json({ message: "El archivo supera el límite de 5MB." });
    }
    return res.status(400).json({ message: err.message });
  }
  if (err) {
    return res.status(400).json({ message: err.message || "Error en la solicitud." });
  }
  next();
});

// ✅ 6. SERVIDOR (VPN)
const PORT = process.env.PORT || 8080;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Servidor Waybee activo en: http://100.81.133.1:${PORT}`);
});
